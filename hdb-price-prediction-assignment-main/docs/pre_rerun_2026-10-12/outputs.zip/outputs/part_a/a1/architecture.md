# A1 baseline architecture

```mermaid
flowchart LR
    Cat[4 categorical features] --> Emb[4 embedding tables, width 12 each]
    Emb --> Join[Concatenate]
    Num[6 standardized continuous features] --> Join
    Join --> Dense[Linear 54 to 256]
    Dense --> Norm[LayerNorm 256]
    Norm --> Relu[ReLU]
    Relu --> Output[Linear 256 to 1]
    Output --> Price[De-normalize to Singapore dollars]
```

- Supplied default baseline parameters (embedding width 8, hidden width 64): 3,505
- Selected A1 model parameters: 16,073
